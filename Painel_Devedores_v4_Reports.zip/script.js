/**
 * Painel de Empréstimos - JS Logic
 * v3.0 - Separação de Devedores/Empréstimos e Relatórios
 */

// --- Estrutura de Dados ---
/**
 * dbDebtors = [ { id, name, phone, notes } ]
 * dbLoans = [ { id, debtorId, type, totalValue, installmentsCount, installments: [], desc, startDate } ]
 */

let dbDebtors = [];
let dbLoans = [];

// --- Inicialização ---

function init() {
    loadData();
    setupListeners();
    updateUI();
}

function loadData() {
    const savedDebtors = localStorage.getItem('painel_devedores_db');
    const savedLoans = localStorage.getItem('painel_emprestimos_v3_db');

    if (savedDebtors) {
        dbDebtors = JSON.parse(savedDebtors);
    }

    if (savedLoans) {
        dbLoans = JSON.parse(savedLoans);
    } else {
        // Tentar migrar da v2?
        const oldData = localStorage.getItem('painel_emprestimos_db');
        if (oldData) {
            migrateData(JSON.parse(oldData));
        } else {
            // Mock inicial se vazio total
            if (dbDebtors.length === 0) {
                const newDebtor = { id: Date.now(), name: "João Mock", phone: "11999999999", notes: "Exemplo" };
                dbDebtors.push(newDebtor);
                dbLoans.push({
                    id: Date.now() + 1,
                    debtorId: newDebtor.id,
                    type: "dinheiro",
                    totalValue: 500.00,
                    installmentsCount: 2,
                    installments: generateInstallments(500, 2, 0),
                    startDate: new Date().toISOString().split('T')[0],
                    desc: "Teste Inicial"
                });
                saveData();
            }
        }
    }
}

function migrateData(oldList) {
    // Converte lista antiga (tudo misturado) para modelo relacional
    oldList.forEach(item => {
        // Cria devedor baseado no item antigo
        const debtorId = item.id; // Usa o mesmo ID para facilitar
        const debtor = {
            id: debtorId,
            name: item.creditor || "Desconhecido",
            phone: item.phone || "",
            notes: item.notes || ""
        };
        dbDebtors.push(debtor);

        // Cria empréstimo linkado
        const loan = {
            id: item.id + "_loan",
            debtorId: debtorId,
            type: item.type,
            totalValue: item.totalValue,
            installmentsCount: item.installmentsCount,
            installments: item.installments,
            startDate: item.startDate,
            desc: item.notes || "" // Repete nota no emprestimo
        };
        dbLoans.push(loan);
    });
    saveData();
    // Limpa v2 para evitar dupla migração futura? Melhor nao, deixa backup.
}

function saveData() {
    localStorage.setItem('painel_devedores_db', JSON.stringify(dbDebtors));
    localStorage.setItem('painel_emprestimos_v3_db', JSON.stringify(dbLoans));
    updateUI();
}

// --- Listeners & Modais ---

const dom = {
    // Body & Filter
    body: document.getElementById('loansTableBody'),
    inputSearch: document.getElementById('filterSearch'),
    filterType: document.getElementById('filterType'),
    filterStatus: document.getElementById('filterStatus'),
    emptyState: document.getElementById('emptyState'),

    // KPIs
    kpiEmprestado: document.getElementById('kpiTotalEmprestado'),
    kpiRecebido: document.getElementById('kpiTotalRecebido'),
    kpiPendente: document.getElementById('kpiTotalPendente'),

    // Modais
    btnNewDebtor: document.getElementById('btnNewDebtor'),
    btnNewLoan: document.getElementById('btnNewLoan'),
    btnReport: document.getElementById('btnReport'),

    modalNewDebtor: document.getElementById('newDebtorModal'),
    modalNewLoan: document.getElementById('newLoanModal'),
    modalReport: document.getElementById('reportModal'),
    modalDetails: document.getElementById('detailsModal'),

    // Forms
    formNewDebtor: document.getElementById('newDebtorForm'),
    formNewLoan: document.getElementById('newLoanForm'),

    // Inputs Loan
    inpLoanDebtor: document.getElementById('inpLoanDebtor'),
    inpLoanType: document.getElementById('inpLoanType'),
    inpLoanDate: document.getElementById('inpLoanDate'),
    inpLoanValue: document.getElementById('inpLoanValue'),
    inpLoanInstallments: document.getElementById('inpLoanInstallments'),
    inpLoanDesc: document.getElementById('inpLoanDesc'),

    // Inputs Report
    inpReportDebtor: document.getElementById('inpReportDebtor'),
    inpReportDate: document.getElementById('inpReportDate'),
    reportPreview: document.getElementById('reportPreview'),
    btnSendReport: document.getElementById('btnSendReport')
};

function setupListeners() {
    dom.inputSearch.addEventListener('input', updateUI);
    dom.filterType.addEventListener('change', updateUI);
    dom.filterStatus.addEventListener('change', updateUI);
    document.getElementById('btnExport').addEventListener('click', exportExcel);

    // Abrir Modais
    dom.btnNewDebtor.onclick = () => openModal('newDebtorModal');
    dom.btnNewLoan.onclick = () => {
        populateDebtorSelect();
        dom.inpLoanDate.valueAsDate = new Date();
        openModal('newLoanModal');
    };
    dom.btnReport.onclick = () => {
        populateDebtorSelect();
        updateReportPreview(); // Limpa
        openModal('reportModal');
    };

    // Fechar Modais (Backdrop)
    document.querySelectorAll('.modal-overlay').forEach(el => {
        el.addEventListener('click', (e) => {
            if (e.target === el) el.classList.add('hidden');
        });
    });
}

function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
}

window.closeModal = (id) => {
    document.getElementById(id).classList.add('hidden');
}

window.openNewDebtorFromLoan = () => {
    closeModal('newLoanModal');
    openModal('newDebtorModal');
}


// --- Lógica de Negócios: Devedores ---

window.handleNewDebtor = function (e) {
    e.preventDefault();
    const name = document.getElementById('inpDebtorName').value;
    const phone = document.getElementById('inpDebtorPhone').value;
    const notes = document.getElementById('inpDebtorNotes').value;

    if (!name) return alert("Obrigatório nome.");

    const newDebtor = {
        id: Date.now(),
        name,
        phone,
        notes
    };
    dbDebtors.push(newDebtor);
    saveData();

    document.getElementById('newDebtorForm').reset();
    closeModal('newDebtorModal');
    alert("Devedor cadastrado com sucesso!");
}

function populateDebtorSelect() {
    const opts = dbDebtors.map(d => `<option value="${d.id}">${d.name}</option>`).join('');
    dom.inpLoanDebtor.innerHTML = `<option value="">Selecione...</option>` + opts;
    dom.inpReportDebtor.innerHTML = `<option value="">Selecione...</option>` + opts;
}


// --- Lógica de Negócios: Empréstimos ---

window.handleNewLoan = function (e) {
    e.preventDefault();
    const debtorId = dom.inpLoanDebtor.value; // ID é string por causa do value, mas no obj é number
    const type = dom.inpLoanType.value;
    const date = dom.inpLoanDate.value;
    const val = parseFloat(dom.inpLoanValue.value);
    const count = parseInt(dom.inpLoanInstallments.value);
    const desc = dom.inpLoanDesc.value;

    if (!debtorId || isNaN(val)) return alert("Preencha corretamente.");

    const newLoan = {
        id: Date.now(),
        debtorId: parseInt(debtorId),
        type,
        startDate: date,
        totalValue: val,
        installmentsCount: count,
        installments: generateInstallments(val, count, 0),
        desc
    };

    dbLoans.push(newLoan);
    saveData();
    dom.formNewLoan.reset();
    closeModal('newLoanModal');
}

function generateInstallments(total, count, paidCount) {
    const val = total / count;
    const list = [];
    for (let i = 1; i <= count; i++) {
        list.push({ number: i, value: val, status: i <= paidCount ? 'Pago' : 'Pendente' });
    }
    return list;
}


// --- Renderização Principal (Tabela) ---

function updateUI() {
    // Merge Loan + Debtor Info for display
    const term = dom.inputSearch.value.toLowerCase();
    const type = dom.filterType.value;
    const statusFilter = dom.filterStatus.value;

    // Join Tables
    const displayData = dbLoans.map(loan => {
        const debtor = dbDebtors.find(d => d.id === loan.debtorId) || { name: "Removido", phone: "" };
        const status = loan.installments.every(i => i.status === 'Pago') ? 'Pago' : 'Pendente';
        return { ...loan, debtorName: debtor.name, debtorPhone: debtor.phone, statusComputed: status };
    });

    const filtered = displayData.filter(item => {
        const matchSearch = item.debtorName.toLowerCase().includes(term);
        const matchType = type === 'all' || item.type === type;
        const matchStatus = statusFilter === 'all' || item.statusComputed === statusFilter;
        return matchSearch && matchType && matchStatus;
    });

    updateKPIs(dbLoans);
    renderTable(filtered);
}

function updateKPIs(loans) {
    let emp = 0, rec = 0, pen = 0;
    loans.forEach(l => {
        emp += l.totalValue;
        l.installments.forEach(i => {
            if (i.status === 'Pago') rec += i.value;
            else pen += i.value;
        });
    });
    dom.kpiEmprestado.textContent = formatMoney(emp);
    dom.kpiRecebido.textContent = formatMoney(rec);
    dom.kpiPendente.textContent = formatMoney(pen);
}

function renderTable(list) {
    dom.body.innerHTML = '';
    if (list.length === 0) {
        dom.emptyState.classList.remove('hidden');
        return;
    }
    dom.emptyState.classList.add('hidden');

    const sorted = [...list].reverse(); // Recentes primeiro

    sorted.forEach(item => {
        const paidCount = item.installments.filter(i => i.status === 'Pago').length;
        const progress = Math.round((paidCount / item.installmentsCount) * 100);
        const stClass = item.statusComputed === 'Pago' ? 'status-pago' : 'status-pendente';

        // WhatsApp Btn
        let waBtn = '<span style="opacity:0.3">-</span>';
        if (item.debtorPhone) {
            const num = item.debtorPhone.replace(/\D/g, '');
            const msg = `Olá ${item.debtorName}, referente ao empréstimo de ${formatMoney(item.totalValue)}...`;
            const link = `https://wa.me/55${num}?text=${encodeURIComponent(msg)}`;
            waBtn = `<a href="${link}" target="_blank" class="btn-whatsapp"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg></a>`;
        }

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>${item.debtorName}</strong><br><span style="font-size:0.75rem; color:#a0aec0">${item.desc || ''}</span></td>
            <td>${waBtn}</td>
            <td><span class="badge-type">${item.type}</span></td>
            <td>${formatMoney(item.totalValue)}</td>
            <td>${paidCount}/${item.installmentsCount}</td>
            <td>
                 <div style="font-size: 0.8rem; color: #a0aec0;">${progress}%</div>
                <div style="width: 100%; height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; margin-top: 4px;">
                    <div style="width: ${progress}%; height: 100%; background: var(--neon-blue); border-radius: 2px;"></div>
                </div>
            </td>
            <td><span class="status-badge ${stClass}"><div class="status-dot"></div>${item.statusComputed}</span></td>
            <td>
                <button class="action-btn" onclick="openDetails(${item.id})">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </button>
            </td>
        `;
        dom.body.appendChild(tr);
    });
}

// --- Detalhes & Pagamento ---
let activeLoanId = null;

window.openDetails = function (id) {
    activeLoanId = id;
    const loan = dbLoans.find(l => l.id === id);
    if (!loan) return;
    const debtor = dbDebtors.find(d => d.id === loan.debtorId) || {};

    document.getElementById('modalTitle').textContent = `Detalhes - ${debtor.name}`;
    document.getElementById('modalTotal').textContent = formatMoney(loan.totalValue);

    // Notes
    let info = '';
    if (debtor.phone) info += `<div><strong>Tel:</strong> ${debtor.phone}</div>`;
    if (loan.desc) info += `<div><strong>Ref:</strong> ${loan.desc}</div>`;
    if (loan.startDate) info += `<div><strong>Data Pag:</strong> ${formatDate(loan.startDate)}</div>`;

    document.getElementById('detailNotesContainer').innerHTML = info;

    // Remaining
    const pend = loan.installments.filter(i => i.status === 'Pendente').reduce((a, b) => a + b.value, 0);
    document.getElementById('modalRestante').textContent = formatMoney(pend);

    // List
    const listEl = document.getElementById('modalInstallmentsList');
    listEl.innerHTML = '';
    loan.installments.forEach(inst => {
        const div = document.createElement('div');
        div.className = `installment-item ${inst.status === 'Pago' ? 'paid' : ''}`;
        div.onclick = () => togglePayment(loan.id, inst.number);
        div.innerHTML = `
            <div class="inst-info">Parcela #${inst.number}</div>
            <div class="inst-value">${formatMoney(inst.value)}</div>
            <div class="inst-status ${inst.status === 'Pago' ? 'pago' : 'pendente'}">${inst.status}</div>
        `;
        listEl.appendChild(div);
    });

    document.getElementById('detailsModal').classList.remove('hidden');
}

function togglePayment(lid, num) {
    const loan = dbLoans.find(l => l.id === lid);
    if (loan) {
        const i = loan.installments.find(x => x.number === num);
        if (i) {
            i.status = i.status === 'Pago' ? 'Pendente' : 'Pago';
            saveData();
            openDetails(lid); // Refresh modal
        }
    }
}

window.deleteCurrentLoan = function () {
    if (activeLoanId && confirm("Excluir empréstimo?")) {
        dbLoans = dbLoans.filter(l => l.id !== activeLoanId);
        saveData();
        closeModal('detailsModal');
    }
}


// --- Relatórios ---

window.updateReportPreview = function () {
    const debtorId = dom.inpReportDebtor.value;
    const dateStr = dom.inpReportDate.value; // YYYY-MM
    const previewEl = dom.reportPreview;
    const btnSend = dom.btnSendReport;

    if (!debtorId) {
        previewEl.innerHTML = '<p style="text-align:center; color: var(--text-secondary)">Selecione um devedor.</p>';
        btnSend.style.display = 'none';
        return;
    }

    const debtor = dbDebtors.find(d => d.id == debtorId);
    const loans = dbLoans.filter(l => l.debtorId == debtorId);

    // Filtrar parcelas
    let lines = [];
    let totalDue = 0;

    loans.forEach(l => {
        l.installments.forEach(inst => {
            if (inst.status === 'Pendente') {
                // Se tiver filtro de data, verificar (assumindo logica simples: data do emprestimo + mes da parcela)
                // Como não calculamos datas exatas, vamos listar TUDO que é pendente se não tiver data,
                // ou apenas tentar filtrar se o usuario selecionou data (o que é dificil sem logica de data real).
                // Simplificação: Mostrar TUDO pendente, pois usuario quer saber "quanto deve".
                lines.push(`- Parcela ${inst.number}/${l.installmentsCount} (${l.desc || 'Empréstimo'}): ${formatMoney(inst.value)}`);
                totalDue += inst.value;
            }
        });
    });

    if (lines.length === 0) {
        previewEl.innerHTML = '<p style="text-align:center;">Nada pendente para este devedor! 🎉</p>';
        btnSend.style.display = 'none';
        return;
    }

    // Montar texto
    const now = new Date().toLocaleDateString('pt-BR');
    let text = `*RELATÓRIO DE COBRANÇA*\n`;
    text += `Olá ${debtor.name}, segue demonstrativo atualizado (${now}):\n\n`;
    text += lines.join('\n');
    text += `\n\n*TOTAL A PAGAR: ${formatMoney(totalDue)}*`;

    previewEl.textContent = text;
    btnSend.style.display = 'flex';

    // Link
    const cleanNum = (debtor.phone || "").replace(/\D/g, '');
    if (cleanNum) {
        btnSend.href = `https://wa.me/55${cleanNum}?text=${encodeURIComponent(text)}`;
    } else {
        btnSend.href = '#';
        btnSend.onclick = () => alert("Devedor sem telefone cadastrado.");
    }
}


// --- Helpers ---
function formatMoney(n) { return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
function formatDate(s) { if (!s) return '-'; const d = new Date(s + "T00:00:00"); return d.toLocaleDateString('pt-BR'); }


// --- Export ---
function exportExcel() {
    let csv = "data:text/csv;charset=utf-8,\uFEFF";
    csv += "Devedor,Telefone,Ref,Valor,Pago,Status,Inicio\n";
    dbLoans.forEach(l => {
        const d = dbDebtors.find(x => x.id === l.debtorId) || { name: '-', phone: '' };
        const st = l.installments.every(i => i.status === 'Pago') ? 'Pago' : 'Pendente';
        const paid = l.installments.filter(i => i.status === 'Pago').reduce((a, b) => a + b.value, 0);
        csv += `${d.name},${d.phone},${l.desc || ''},${l.totalValue.toFixed(2)},${paid.toFixed(2)},${st},${l.startDate}\n`;
    });
    const link = document.createElement("a");
    link.href = encodeURI(csv);
    link.download = "relatorio_geral.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

init();