/**
 * Painel de Empréstimos - JS Logic
 * 100% Vanilla JS, Gerenciamento de Devedores
 * LocalStorage para persistência
 */

// --- Dados Iniciais (Exemplo) ---
// Só usado se não houver nada salvo
const exemploInicial = [
    {
        id: 1709251200000,
        creditor: "João da Silva", // mantendo 'creditor' no obj para compatibilidade interna, mas na UI é Devedor
        type: "dinheiro",
        totalValue: 5000.00,
        installmentsCount: 10,
        startDate: "2023-10-01",
        installments: generateInstallments(5000, 10, 3)
    }
];

// Helper para gerar parcelas
function generateInstallments(total, count, paidCount) {
    const valuePerInst = total / count;
    const list = [];
    for (let i = 1; i <= count; i++) {
        list.push({
            number: i,
            value: valuePerInst,
            status: i <= paidCount ? 'Pago' : 'Pendente'
        });
    }
    return list;
}

// --- Estado & Persistência ---
let currentData = [];

function loadData() {
    const saved = localStorage.getItem('painel_emprestimos_db');
    if (saved) {
        currentData = JSON.parse(saved);
    } else {
        currentData = [...exemploInicial];
        saveData();
    }
}

function saveData() {
    localStorage.setItem('painel_emprestimos_db', JSON.stringify(currentData));
    updateUI();
}

// --- Elementos DOM ---
const dom = {
    kpiEmprestado: document.getElementById('kpiTotalEmprestado'),
    kpiRecebido: document.getElementById('kpiTotalRecebido'),
    kpiPendente: document.getElementById('kpiTotalPendente'),
    body: document.getElementById('loansTableBody'),
    inputSearch: document.getElementById('filterSearch'),
    filterType: document.getElementById('filterType'),
    filterStatus: document.getElementById('filterStatus'),
    btnExport: document.getElementById('btnExport'),
    btnNewLoan: document.getElementById('btnNewLoan'),
    emptyState: document.getElementById('emptyState'),

    // Modais
    modalDetails: document.getElementById('detailsModal'),
    modalNew: document.getElementById('newLoanModal'),

    // Detalhes
    detailTitle: document.getElementById('modalTitle'),
    detailTotal: document.getElementById('modalTotal'),
    detailRestante: document.getElementById('modalRestante'),
    detailList: document.getElementById('modalInstallmentsList'),

    // Formulário
    formNewLoan: document.getElementById('newLoanForm'),
    inpName: document.getElementById('inpName'),
    inpType: document.getElementById('inpType'),
    inpDate: document.getElementById('inpDate'),
    inpValue: document.getElementById('inpValue'),
    inpInstallments: document.getElementById('inpInstallments')
};

let activeLoanId = null;

// --- Inicialização ---
function init() {
    loadData();
    setupListeners();
    updateUI();
}

function setupListeners() {
    dom.inputSearch.addEventListener('input', updateUI);
    dom.filterType.addEventListener('change', updateUI);
    dom.filterStatus.addEventListener('change', updateUI);
    dom.btnExport.addEventListener('click', exportExcel);

    // Modal Abertura
    dom.btnNewLoan.addEventListener('click', () => {
        dom.modalNew.classList.remove('hidden');
        dom.inpDate.valueAsDate = new Date(); // Hoje por padrão
    });

    // Modal Fechamento (Backdrop)
    [dom.modalDetails, dom.modalNew].forEach(el => {
        el.addEventListener('click', (e) => {
            if (e.target === el) el.classList.add('hidden');
        });
    });
}

// Funções globais para botões de fechar no HTML
window.closeDetailsModal = () => dom.modalDetails.classList.add('hidden');
window.closeNewLoanModal = () => dom.modalNew.classList.add('hidden');

// --- Lógica de Renderização ---

function updateUI() {
    // 1. Filtragem
    const term = dom.inputSearch.value.toLowerCase();
    const type = dom.filterType.value;
    const status = dom.filterStatus.value;

    const filtered = currentData.filter(item => {
        const matchSearch = item.creditor.toLowerCase().includes(term);
        const matchType = type === 'all' || item.type === type;
        const itemStatus = getLoanStatus(item.installments);
        const matchStatus = status === 'all' || itemStatus === status;
        return matchSearch && matchType && matchStatus;
    });

    // 2. Renderizar KPIs
    updateKPIs(currentData); // KPIs sempre mostram o total global ou filtrado? Geralmente global, mas aqui farei global.

    // 3. Renderizar Tabela
    renderTable(filtered);

    // Se o modal de detalhes estiver aberto, atualiza ele também (para refletir pagamentos)
    if (!dom.modalDetails.classList.contains('hidden') && activeLoanId) {
        window.openDetails(activeLoanId);
    }
}

function updateKPIs(data) {
    let totalEmprestado = 0;
    let totalRecebido = 0;
    let totalPendente = 0;

    data.forEach(item => {
        totalEmprestado += item.totalValue;
        item.installments.forEach(inst => {
            if (inst.status === 'Pago') {
                totalRecebido += inst.value;
            } else {
                totalPendente += inst.value;
            }
        });
    });

    dom.kpiEmprestado.textContent = formatCurrency(totalEmprestado);
    dom.kpiRecebido.textContent = formatCurrency(totalRecebido);
    dom.kpiPendente.textContent = formatCurrency(totalPendente);
}

function renderTable(data) {
    dom.body.innerHTML = '';

    if (data.length === 0) {
        dom.emptyState.classList.remove('hidden');
        return;
    }
    dom.emptyState.classList.add('hidden');

    // Ordenar por mais recente? Vamos manter ordem de criação.
    // Inverter array para mostrar mais novos primeiro
    const list = [...data].reverse();

    list.forEach(item => {
        const tr = document.createElement('tr');

        const paidCount = item.installments.filter(i => i.status === 'Pago').length;
        const progress = Math.round((paidCount / item.installmentsCount) * 100);
        const status = getLoanStatus(item.installments);
        const statusClass = status === 'Pago' ? 'status-pago' : 'status-pendente';

        tr.innerHTML = `
            <td><strong>${item.creditor}</strong></td>
            <td><span class="badge-type">${item.type === 'cartao' ? 'Cartão' : 'Dinheiro'}</span></td>
            <td>${formatCurrency(item.totalValue)}</td>
            <td>${paidCount}/${item.installmentsCount}</td>
            <td>
                <div style="font-size: 0.8rem; color: #a0aec0;">${progress}%</div>
                <div style="width: 100%; height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; margin-top: 4px;">
                    <div style="width: ${progress}%; height: 100%; background: var(--neon-blue); border-radius: 2px;"></div>
                </div>
            </td>
            <td>
                <span class="status-badge ${statusClass}">
                    <div class="status-dot"></div> ${status}
                </span>
            </td>
            <td>
                <button class="action-btn" onclick="openDetails(${item.id})" title="Ver Detalhes">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </button>
            </td>
        `;
        dom.body.appendChild(tr);
    });
}

function getLoanStatus(installments) {
    const allPaid = installments.every(i => i.status === 'Pago');
    return allPaid ? 'Pago' : 'Pendente';
}

function formatCurrency(value) {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// --- Detalhes e Pagamentos ---

window.openDetails = function (id) {
    activeLoanId = id;
    const item = currentData.find(d => d.id === id);
    if (!item) return;

    dom.detailTitle.textContent = `Empréstimo - ${item.creditor}`;
    dom.detailTotal.textContent = formatCurrency(item.totalValue);

    const remaining = item.installments
        .filter(i => i.status === 'Pendente')
        .reduce((acc, curr) => acc + curr.value, 0);
    dom.detailRestante.textContent = formatCurrency(remaining);

    dom.detailList.innerHTML = '';
    item.installments.forEach(inst => {
        const div = document.createElement('div');
        div.className = `installment-item ${inst.status === 'Pago' ? 'paid' : ''}`;
        div.onclick = () => togglePayment(item.id, inst.number);

        const statusClass = inst.status === 'Pago' ? 'pago' : 'pendente';
        const label = inst.status === 'Pago' ? 'PAGO' : 'PENDENTE';

        div.innerHTML = `
            <div class="inst-info">Parcela #${inst.number}</div>
            <div class="inst-value">
                ${formatCurrency(inst.value)}
            </div>
            <div class="inst-status ${statusClass}">
                ${label}
            </div>
        `;
        dom.detailList.appendChild(div);
    });

    dom.modalDetails.classList.remove('hidden');
}

function togglePayment(loanId, installmentNum) {
    const loan = currentData.find(d => d.id === loanId);
    if (!loan) return;

    const installment = loan.installments.find(i => i.number === installmentNum);
    if (installment) {
        // Inverte status
        installment.status = installment.status === 'Pago' ? 'Pendente' : 'Pago';
        saveData(); // Salva e atualiza UI
    }
}

window.deleteCurrentLoan = function () {
    if (!activeLoanId) return;
    if (confirm("Tem certeza que deseja excluir este cadastro?")) {
        currentData = currentData.filter(d => d.id !== activeLoanId);
        saveData();
        dom.modalDetails.classList.add('hidden');
    }
}


// --- Novo Empréstimo ---

window.handleNewLoan = function (e) {
    e.preventDefault();

    // Captura valores
    const name = dom.inpName.value;
    const type = dom.inpType.value;
    const date = dom.inpDate.value;
    const valTotal = parseFloat(dom.inpValue.value);
    const count = parseInt(dom.inpInstallments.value);

    // Validação básica
    if (!name || isNaN(valTotal) || isNaN(count) || count < 1) {
        alert("Preencha todos os campos corretamente.");
        return;
    }

    // Cria objeto
    const newLoan = {
        id: Date.now(), // timestamp como ID único
        creditor: name,
        type: type,
        totalValue: valTotal,
        installmentsCount: count,
        startDate: date,
        installments: generateInstallments(valTotal, count, 0)
    };

    // Salva
    currentData.push(newLoan);
    saveData();

    // Limpa e Fecha
    dom.formNewLoan.reset();
    dom.modalNew.classList.add('hidden');
}


// --- Exportação ---
function exportExcel() {
    let csvContent = "data:text/csv;charset=utf-8,\uFEFF";
    csvContent += "Devedor,Tipo,Valor Total,Parcelas Pagas,Parcelas Totais,Status,Data Início\n";

    currentData.forEach(item => {
        const paidCount = item.installments.filter(i => i.status === 'Pago').length;
        const status = getLoanStatus(item.installments);

        const row = [
            item.creditor,
            item.type,
            item.totalValue.toFixed(2),
            paidCount,
            item.installmentsCount,
            status,
            item.startDate || "-"
        ];
        csvContent += row.join(",") + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "controle_devedores.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Iniciar
init();