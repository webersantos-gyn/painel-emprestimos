PAINEL DE EMPRÉSTIMO
====================

Instruções de Uso:
1. Abra o arquivo 'index.html' no seu navegador (Chrome, Edge, Firefox).
2. O dashboard carregará automaticamente com dados de exemplo.
3. Utilize a barra de topo para Exportar para Excel (.csv).
4. Utilize a barra de filtros para buscar por nome, tipo (Dinheiro/Cartão) ou Status.
5. Clique no ícone de "olho" na tabela para ver os detalhes das parcelas.

Tecnologias:
- HTML5
- CSS3 (Inter Neon Pro Style)
- JavaScript Vanilla

Notas:
- Funciona 100% offline.
- Totalmente responsivo (Mobile/Desktop).
- Para testar, basta abrir o index.html.

Versão 1.0