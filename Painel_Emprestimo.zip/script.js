/**
 * Painel de Empréstimo - JS Logic
 * 100% Vanilla JS, No external dependencies.
 */

// --- Initial Data (Mock) ---
const rawData = [
    {
        id: 1,
        creditor: "João da Silva",
        type: "dinheiro", // 'dinheiro' | 'cartao'
        totalValue: 5000.00,
        installmentsCount: 10,
        date: "2023-10-01",
        installments: generateInstallments(5000, 10, 3) // 3 paid
    },
    {
        id: 2,
        creditor: "Maria Souza",
        type: "cartao",
        totalValue: 1200.50,
        installmentsCount: 4,
        date: "2023-11-15",
        installments: generateInstallments(1200.50, 4, 1) // 1 paid
    },
    {
        id: 3,
        creditor: "Roberto Carlos",
        type: "dinheiro",
        totalValue: 15000.00,
        installmentsCount: 24,
        date: "2023-05-10",
        installments: generateInstallments(15000, 24, 12) // 12 paid
    },
    {
        id: 4,
        creditor: "Ana Paula",
        type: "cartao",
        totalValue: 850.00,
        installmentsCount: 2,
        date: "2023-12-01",
        installments: generateInstallments(850, 2, 2) // All paid
    },
    {
        id: 5,
        creditor: "Empresa XYZ",
        type: "dinheiro",
        totalValue: 3000.00,
        installmentsCount: 5,
        date: "2024-01-05",
        installments: generateInstallments(3000, 5, 0) // 0 paid
    }
];

// Helper to generate installments structure
function generateInstallments(total, count, paidCount) {
    const valuePerInst = total / count;
    const list = [];
    for (let i = 1; i <= count; i++) {
        list.push({
            number: i,
            value: valuePerInst,
            status: i <= paidCount ? 'Pago' : 'Pendente'
        });
    }
    return list;
}

// State
let currentData = [...rawData];

// --- DOM Elements ---
const dom = {
    kpiEmprestado: document.getElementById('kpiTotalEmprestado'),
    kpiRecebido: document.getElementById('kpiTotalRecebido'),
    kpiPendente: document.getElementById('kpiTotalPendente'),
    body: document.getElementById('loansTableBody'),
    inputSearch: document.getElementById('filterSearch'),
    filterType: document.getElementById('filterType'),
    filterStatus: document.getElementById('filterStatus'),
    btnExport: document.getElementById('btnExport'),
    emptyState: document.getElementById('emptyState'),
    modal: {
        self: document.getElementById('detailsModal'),
        title: document.getElementById('modalTitle'),
        total: document.getElementById('modalTotal'),
        restante: document.getElementById('modalRestante'),
        list: document.getElementById('modalInstallmentsList')
    }
};

// --- Initialization ---
function init() {
    render();
    setupListeners();
}

// --- Core Logic ---

function setupListeners() {
    dom.inputSearch.addEventListener('input', handleFilter);
    dom.filterType.addEventListener('change', handleFilter);
    dom.filterStatus.addEventListener('change', handleFilter);
    dom.btnExport.addEventListener('click', exportExcel);
}

function handleFilter() {
    const term = dom.inputSearch.value.toLowerCase();
    const type = dom.filterType.value;
    const status = dom.filterStatus.value;

    currentData = rawData.filter(item => {
        // Search
        const matchSearch = item.creditor.toLowerCase().includes(term);
        // Type
        const matchType = type === 'all' || item.type === type;
        // Status (Derived)
        const itemStatus = getLoanStatus(item.installments);
        const matchStatus = status === 'all' || itemStatus === status;

        return matchSearch && matchType && matchStatus;
    });

    render();
}

function render() {
    updateKPIs(currentData);
    renderTable(currentData);
}

function updateKPIs(data) {
    let totalEmprestado = 0;
    let totalRecebido = 0;
    let totalPendente = 0;

    data.forEach(item => {
        totalEmprestado += item.totalValue;
        item.installments.forEach(inst => {
            if (inst.status === 'Pago') {
                totalRecebido += inst.value;
            } else {
                totalPendente += inst.value;
            }
        });
    });

    dom.kpiEmprestado.textContent = formatCurrency(totalEmprestado);
    dom.kpiRecebido.textContent = formatCurrency(totalRecebido);
    dom.kpiPendente.textContent = formatCurrency(totalPendente);
}

function renderTable(data) {
    dom.body.innerHTML = '';

    if (data.length === 0) {
        dom.emptyState.classList.remove('hidden');
        return;
    }
    dom.emptyState.classList.add('hidden');

    data.forEach(item => {
        const tr = document.createElement('tr');

        const paidCount = item.installments.filter(i => i.status === 'Pago').length;
        const progress = Math.round((paidCount / item.installmentsCount) * 100);
        const status = getLoanStatus(item.installments);
        const statusClass = status === 'Pago' ? 'status-pago' : 'status-pendente';

        tr.innerHTML = `
            <td><strong>${item.creditor}</strong></td>
            <td><span class="badge-type">${item.type === 'cartao' ? 'Cartão' : 'Dinheiro'}</span></td>
            <td>${formatCurrency(item.totalValue)}</td>
            <td>${paidCount}/${item.installmentsCount}</td>
            <td>
                <div style="font-size: 0.8rem; color: #a0aec0;">${progress}%</div>
                <div style="width: 100%; height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; margin-top: 4px;">
                    <div style="width: ${progress}%; height: 100%; background: var(--neon-blue); border-radius: 2px;"></div>
                </div>
            </td>
            <td>
                <span class="status-badge ${statusClass}">
                    <div class="status-dot"></div> ${status}
                </span>
            </td>
            <td>
                <button class="action-btn" onclick="openDetails(${item.id})">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </button>
            </td>
        `;
        dom.body.appendChild(tr);
    });
}

function getLoanStatus(installments) {
    const allPaid = installments.every(i => i.status === 'Pago');
    return allPaid ? 'Pago' : 'Pendente';
}

function formatCurrency(value) {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// --- Modal Logic ---

// Expose to global scope for HTML onclick
window.openDetails = function (id) {
    const item = rawData.find(d => d.id === id);
    if (!item) return;

    dom.modal.title.textContent = `Empréstimo - ${item.creditor}`;
    dom.modal.total.textContent = formatCurrency(item.totalValue);

    // Calc remaining
    const remaining = item.installments
        .filter(i => i.status === 'Pendente')
        .reduce((acc, curr) => acc + curr.value, 0);
    dom.modal.restante.textContent = formatCurrency(remaining);

    // List
    dom.modal.list.innerHTML = '';
    item.installments.forEach(inst => {
        const div = document.createElement('div');
        div.className = `installment-item ${inst.status === 'Pago' ? 'paid' : ''}`;

        const statusClass = inst.status === 'Pago' ? 'pago' : 'pendente';

        div.innerHTML = `
            <div class="inst-info">Parcela #${inst.number}</div>
            <div class="inst-value">${formatCurrency(inst.value)}</div>
            <div class="inst-status ${statusClass}">${inst.status}</div>
        `;
        dom.modal.list.appendChild(div);
    });

    dom.modal.self.classList.remove('hidden');
}

window.closeModal = function () {
    dom.modal.self.classList.add('hidden');
}

// Explicit close on backdrop click
dom.modal.self.addEventListener('click', (e) => {
    if (e.target === dom.modal.self) window.closeModal();
});


// --- Export Logic ---
function exportExcel() {
    // CSV Header
    let csvContent = "data:text/csv;charset=utf-8,\uFEFF";
    csvContent += "Credor,Tipo,Valor Total,Parcelas Pagas,Parcelas Totais,Status\n";

    // Rows
    currentData.forEach(item => {
        const paidCount = item.installments.filter(i => i.status === 'Pago').length;
        const status = getLoanStatus(item.installments);

        const row = [
            item.creditor,
            item.type,
            item.totalValue.toFixed(2),
            paidCount,
            item.installmentsCount,
            status
        ];
        csvContent += row.join(",") + "\n";
    });

    // Download
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "emprestimos_dashboard.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Start
init();